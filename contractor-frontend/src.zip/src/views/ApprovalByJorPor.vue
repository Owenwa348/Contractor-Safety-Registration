<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold text-blue-600">รอการอนุมัติโดย จป.</h1>
    <p class="text-gray-600">เจ้าหน้าที่ จป. จะอนุมัติเอกสารขั้นสุดท้าย</p>
  </div>
</template>
