<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold text-blue-600">พิมพ์บัตรผู้รับเหมา</h1>
    <p class="text-gray-600">เลือกรายชื่อและพิมพ์บัตรผ่านระบบ</p>
  </div>
</template>
