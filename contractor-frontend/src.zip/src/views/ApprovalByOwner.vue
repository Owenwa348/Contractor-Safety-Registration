<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold text-blue-600">รอการอนุมัติโดยเจ้าของงาน</h1>
    <p class="text-gray-600">เจ้าของงานจะอนุมัติเอกสารก่อนส่งต่อให้ จป.</p>
  </div>
</template>
