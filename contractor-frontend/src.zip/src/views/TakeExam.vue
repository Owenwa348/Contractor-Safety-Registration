<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold text-blue-600">ทำแบบทดสอบหลังอบรม</h1>
    <p class="text-gray-600">สแกน QR เพื่อเข้าสู่การสอบ</p>
  </div>
</template>
