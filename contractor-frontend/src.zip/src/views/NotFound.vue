<template>
  <div class="flex flex-col items-center justify-center h-screen text-center">
    <h1 class="text-4xl font-bold text-red-600 mb-4">404</h1>
    <p class="text-gray-600 mb-2">ไม่พบหน้าที่คุณต้องการ</p>
    <router-link to="/" class="text-blue-500 hover:underline">กลับหน้าแรก</router-link>
  </div>
</template>
