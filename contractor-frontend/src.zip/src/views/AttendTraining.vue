<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold text-blue-600">เข้าอบรม</h1>
    <p class="text-gray-600">ทีมงานเข้าร่วมอบรมตามเวลาที่กำหนด</p>
  </div>
</template>
