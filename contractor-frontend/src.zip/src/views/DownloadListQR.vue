<template>
  <div class="p-6">
    <h1 class="text-xl font-semibold text-blue-600">ดาวน์โหลดรายชื่อ + QR Code</h1>
    <p class="text-gray-600">สำหรับเจ้าหน้าที่ ดาวน์โหลดรายชื่อและเปิด QR สแกน</p>
  </div>
</template>
